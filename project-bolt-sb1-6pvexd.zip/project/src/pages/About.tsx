import React from 'react';
import { Link } from 'react-router-dom';
import { Code, Palette, Globe, Coffee } from 'lucide-react';
import SectionHeader from '../components/SectionHeader';

const About = () => {
  const passions = [
    {
      icon: <Code className="w-8 h-8" />,
      title: 'Clean Code',
      description: 'Writing maintainable, efficient, and elegant solutions.',
    },
    {
      icon: <Palette className="w-8 h-8" />,
      title: 'Creative Design',
      description: 'Crafting beautiful and intuitive user experiences.',
    },
    {
      icon: <Globe className="w-8 h-8" />,
      title: 'Global Impact',
      description: 'Building solutions that make a difference worldwide.',
    },
    {
      icon: <Coffee className="w-8 h-8" />,
      title: 'Continuous Learning',
      description: 'Always staying current with the latest technologies.',
    },
  ];

  return (
    <div className="pt-24">
      <SectionHeader
        title="About Me"
        subtitle="Passionate developer crafting digital experiences that matter"
      />

      {/* Personal Story */}
      <section className="py-16 bg-gradient-to-b from-gray-50">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="https://images.unsplash.com/photo-1544717297-fa95b6ee9643?auto=format&fit=crop&q=80&w=800"
                alt="Profile"
                className="rounded-lg shadow-xl"
              />
            </div>
            <div>
              <h2 className="text-3xl font-bold mb-6">My Journey</h2>
              <div className="space-y-4 text-lg text-gray-700">
                <p>
                  With over a decade of experience in software development, I've had
                  the privilege of working on projects that push the boundaries of
                  what's possible on the web.
                </p>
                <p>
                  My approach combines technical expertise with creative
                  problem-solving, ensuring that every solution is not just
                  functional, but exceptional.
                </p>
                <p>
                  When I'm not coding, you'll find me exploring new technologies,
                  contributing to open-source projects, or mentoring aspiring
                  developers.
                </p>
              </div>
              <Link
                to="/contact"
                className="btn btn-primary mt-8"
              >
                Let's Connect
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Passions */}
      <section className="py-16">
        <div className="container-custom">
          <h2 className="text-3xl font-bold text-center mb-12">What Drives Me</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {passions.map((passion, index) => (
              <div
                key={index}
                className="p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="text-indigo-600 mb-4">{passion.icon}</div>
                <h3 className="text-xl font-bold mb-2">{passion.title}</h3>
                <p className="text-gray-600">{passion.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;