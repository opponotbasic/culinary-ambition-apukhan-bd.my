import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, Github, Maximize2, X } from 'lucide-react';
import SectionHeader from '../components/SectionHeader';

interface Project {
  id: number;
  title: string;
  category: string;
  image: string;
  description: string;
  technologies: string[];
  links: {
    live?: string;
    github?: string;
  };
}

const Portfolio = () => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [activeCategory, setActiveCategory] = useState('all');

  const projects: Project[] = [
    {
      id: 1,
      title: "AI-Powered Analytics Dashboard",
      category: "web",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800",
      description: "An innovative analytics platform leveraging AI to provide predictive insights and real-time data visualization.",
      technologies: ["React", "TypeScript", "TensorFlow.js", "D3.js"],
      links: {
        live: "https://example.com",
        github: "https://github.com"
      }
    },
    {
      id: 2,
      title: "Sustainable Energy Monitor",
      category: "mobile",
      image: "https://images.unsplash.com/photo-1548611716-ad9721253226?auto=format&fit=crop&q=80&w=800",
      description: "Mobile application for tracking and optimizing renewable energy consumption patterns.",
      technologies: ["React Native", "Redux", "Node.js", "MongoDB"],
      links: {
        live: "https://example.com"
      }
    },
    {
      id: 3,
      title: "Virtual Art Gallery",
      category: "design",
      image: "https://images.unsplash.com/photo-1561214115-f2f134cc4912?auto=format&fit=crop&q=80&w=800",
      description: "Interactive 3D virtual gallery showcasing digital art collections with VR support.",
      technologies: ["Three.js", "WebGL", "React", "Firebase"],
      links: {
        github: "https://github.com"
      }
    },
    {
      id: 4,
      title: "Smart City Platform",
      category: "web",
      image: "https://images.unsplash.com/photo-1573164713714-d95e436ab8d6?auto=format&fit=crop&q=80&w=800",
      description: "Comprehensive platform for managing and monitoring smart city infrastructure.",
      technologies: ["Next.js", "GraphQL", "PostgreSQL", "Docker"],
      links: {
        live: "https://example.com",
        github: "https://github.com"
      }
    }
  ];

  const categories = ['all', 'web', 'mobile', 'design'];

  const filteredProjects = projects.filter(
    project => activeCategory === 'all' || project.category === activeCategory
  );

  return (
    <div className="pt-24 min-h-screen bg-gradient-to-br from-gray-50 to-white">
      <SectionHeader
        title="Portfolio"
        subtitle="Exploring the intersection of design and technology"
      />

      {/* Category Filter */}
      <div className="container-custom mb-12">
        <div className="flex justify-center space-x-4">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-6 py-2 rounded-full transition-all duration-300 ${
                activeCategory === category
                  ? 'bg-indigo-600 text-white shadow-lg'
                  : 'bg-white text-gray-600 hover:bg-indigo-50'
              }`}
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Projects Grid */}
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
          {filteredProjects.map((project) => (
            <motion.div
              key={project.id}
              layout
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="group relative overflow-hidden rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300"
            >
              <div className="relative h-[400px] overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                    <h3 className="text-2xl font-bold mb-2">{project.title}</h3>
                    <p className="text-gray-200 mb-4">{project.description}</p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.technologies.map((tech) => (
                        <span
                          key={tech}
                          className="px-3 py-1 bg-white/20 rounded-full text-sm"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                    <button
                      onClick={() => setSelectedProject(project)}
                      className="btn bg-white text-gray-900 hover:bg-gray-100"
                    >
                      <Maximize2 className="w-4 h-4 mr-2" />
                      View Details
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Project Modal */}
      {selectedProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="relative bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
          >
            <button
              onClick={() => setSelectedProject(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
            <div className="p-8">
              <img
                src={selectedProject.image}
                alt={selectedProject.title}
                className="w-full h-[400px] object-cover rounded-lg mb-8"
              />
              <h2 className="text-3xl font-bold mb-4">{selectedProject.title}</h2>
              <p className="text-gray-600 mb-6">{selectedProject.description}</p>
              <div className="flex flex-wrap gap-2 mb-6">
                {selectedProject.technologies.map((tech) => (
                  <span
                    key={tech}
                    className="px-4 py-2 bg-gray-100 rounded-full text-sm"
                  >
                    {tech}
                  </span>
                ))}
              </div>
              <div className="flex gap-4">
                {selectedProject.links.live && (
                  <a
                    href={selectedProject.links.live}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-primary"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    View Live
                  </a>
                )}
                {selectedProject.links.github && (
                  <a
                    href={selectedProject.links.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn bg-gray-900 text-white hover:bg-gray-800"
                  >
                    <Github className="w-4 h-4 mr-2" />
                    View Code
                  </a>
                )}
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default Portfolio;