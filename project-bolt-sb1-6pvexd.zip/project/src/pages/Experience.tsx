import React from 'react';
import { Calendar, MapPin, Award } from 'lucide-react';
import SectionHeader from '../components/SectionHeader';

const Experience = () => {
  const experiences = [
    {
      title: 'Senior Software Engineer',
      company: 'Tech Innovators Inc.',
      period: '2020 - Present',
      location: 'San Francisco, CA',
      description: [
        'Led development of cloud-native applications using React and Node.js',
        'Mentored junior developers and established best practices',
        'Improved application performance by 40% through optimization',
      ],
    },
    {
      title: 'Full Stack Developer',
      company: 'Digital Solutions Ltd.',
      period: '2018 - 2020',
      location: 'New York, NY',
      description: [
        'Developed and maintained multiple client applications',
        'Implemented CI/CD pipelines reducing deployment time by 60%',
        'Collaborated with UX team to improve user experience',
      ],
    },
    {
      title: 'Frontend Developer',
      company: 'Creative Web Agency',
      period: '2016 - 2018',
      location: 'Boston, MA',
      description: [
        'Built responsive web applications using modern frameworks',
        'Integrated third-party APIs and services',
        'Reduced load times by 50% through optimization techniques',
      ],
    },
  ];

  const education = [
    {
      degree: 'Master of Computer Science',
      school: 'Tech University',
      year: '2016',
      description: 'Focus on Software Engineering and AI',
    },
    {
      degree: 'Bachelor of Science in Computer Science',
      school: 'State University',
      year: '2014',
      description: 'Minor in Mathematics',
    },
  ];

  return (
    <div className="pt-24">
      <SectionHeader
        title="Experience"
        subtitle="A journey of continuous growth and impactful contributions"
      />

      {/* Work Experience */}
      <section className="py-16">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12">Work History</h2>
            <div className="space-y-12">
              {experiences.map((exp, index) => (
                <div
                  key={index}
                  className="relative pl-8 border-l-2 border-indigo-200 hover:border-indigo-600 transition-colors"
                >
                  <div className="absolute -left-3 top-0 w-6 h-6 bg-white border-2 border-indigo-600 rounded-full" />
                  <div className="mb-4">
                    <h3 className="text-2xl font-bold text-gray-900">
                      {exp.title}
                    </h3>
                    <div className="text-lg font-semibold text-indigo-600">
                      {exp.company}
                    </div>
                    <div className="flex items-center gap-4 text-gray-600 mt-2">
                      <span className="flex items-center">
                        <Calendar className="w-4 h-4 mr-1" />
                        {exp.period}
                      </span>
                      <span className="flex items-center">
                        <MapPin className="w-4 h-4 mr-1" />
                        {exp.location}
                      </span>
                    </div>
                  </div>
                  <ul className="list-disc list-inside space-y-2 text-gray-700">
                    {exp.description.map((item, i) => (
                      <li key={i}>{item}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Education */}
      <section className="py-16 bg-gray-50">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12">Education</h2>
            <div className="grid gap-8">
              {education.map((edu, index) => (
                <div
                  key={index}
                  className="bg-white p-8 rounded-lg shadow-lg hover:shadow-xl transition-shadow"
                >
                  <div className="flex items-start gap-4">
                    <Award className="w-8 h-8 text-indigo-600 flex-shrink-0" />
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">
                        {edu.degree}
                      </h3>
                      <div className="text-lg text-indigo-600">{edu.school}</div>
                      <div className="text-gray-600 mt-1">
                        Graduated {edu.year}
                      </div>
                      <p className="text-gray-700 mt-2">{edu.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Experience;