import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <>
      {/* Hero Section */}
      <section className="relative h-screen flex items-center">
        <div
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: 'url(https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        >
          <div className="absolute inset-0 bg-black/50"></div>
        </div>
        
        <div className="container-custom relative z-10 text-white">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 animate-fade-in">
            Crafting Digital
            <br />
            Experiences
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-2xl">
            Transforming ideas into elegant, high-performance solutions that make a difference.
          </p>
          <Link
            to="/portfolio"
            className="btn btn-primary inline-flex items-center group"
          >
            View My Work
            <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </section>

      {/* Featured Work */}
      <section className="py-24 bg-gray-50">
        <div className="container-custom">
          <h2 className="text-4xl font-bold mb-12 text-center">Featured Work</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[1, 2, 3].map((item) => (
              <div
                key={item}
                className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow"
              >
                <img
                  src={`https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&q=80&w=600`}
                  alt="Project preview"
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">Project {item}</h3>
                  <p className="text-gray-600 mb-4">
                    A brief description of this amazing project and its impact.
                  </p>
                  <Link
                    to={`/portfolio/project-${item}`}
                    className="text-indigo-600 hover:text-indigo-700 font-medium inline-flex items-center group"
                  >
                    Learn More
                    <ArrowRight className="ml-1 group-hover:translate-x-1 transition-transform" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section className="py-24">
        <div className="container-custom">
          <h2 className="text-4xl font-bold mb-12 text-center">Skills & Expertise</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              'Frontend Development',
              'Backend Architecture',
              'UI/UX Design',
              'Cloud Solutions',
              'Performance Optimization',
              'Security Implementation',
            ].map((skill) => (
              <div
                key={skill}
                className="p-6 border border-gray-200 rounded-lg hover:border-indigo-500 transition-colors"
              >
                <h3 className="text-xl font-bold mb-2">{skill}</h3>
                <p className="text-gray-600">
                  Expertise in delivering high-quality solutions using modern technologies
                  and best practices.
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-indigo-600 text-white">
        <div className="container-custom text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Start Your Project?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Let's collaborate to bring your vision to life with cutting-edge technology
            and exceptional design.
          </p>
          <Link to="/contact" className="btn bg-white text-indigo-600 hover:bg-gray-100">
            Get in Touch
          </Link>
        </div>
      </section>
    </>
  );
};

export default Home;