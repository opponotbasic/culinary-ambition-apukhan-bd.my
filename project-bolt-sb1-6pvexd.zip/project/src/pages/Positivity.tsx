import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, Share2, MessageCircle, Sparkles, Award, Users, ThumbsUp } from 'lucide-react';
import SectionHeader from '../components/SectionHeader';

interface Quote {
  id: number;
  text: string;
  author: string;
  likes: number;
  comments: number;
  shares: number;
  category: string;
  image: string;
}

const Positivity = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [likedQuotes, setLikedQuotes] = useState<number[]>([]);

  const quotes: Quote[] = [
    {
      id: 1,
      text: "The only way to do great work is to love what you do.",
      author: "Steve Jobs",
      likes: 1234,
      comments: 89,
      shares: 456,
      category: "motivation",
      image: "https://images.unsplash.com/photo-1496449903678-68ddcb189a24?auto=format&fit=crop&q=80&w=800"
    },
    {
      id: 2,
      text: "Happiness is not something ready made. It comes from your own actions.",
      author: "Dalai Lama",
      likes: 987,
      comments: 65,
      shares: 321,
      category: "happiness",
      image: "https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&q=80&w=800"
    },
    {
      id: 3,
      text: "The future belongs to those who believe in the beauty of their dreams.",
      author: "Eleanor Roosevelt",
      likes: 765,
      comments: 43,
      shares: 234,
      category: "dreams",
      image: "https://images.unsplash.com/photo-1488085061387-422e29b40080?auto=format&fit=crop&q=80&w=800"
    },
    {
      id: 4,
      text: "The best way to predict the future is to create it.",
      author: "Peter Drucker",
      likes: 543,
      comments: 32,
      shares: 178,
      category: "motivation",
      image: "https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&q=80&w=800"
    }
  ];

  const categories = ['all', ...new Set(quotes.map(quote => quote.category))];

  const filteredQuotes = quotes.filter(
    quote => selectedCategory === 'all' || quote.category === selectedCategory
  );

  const handleLike = (quoteId: number) => {
    setLikedQuotes(prev => 
      prev.includes(quoteId) 
        ? prev.filter(id => id !== quoteId)
        : [...prev, quoteId]
    );
  };

  const stats = [
    { icon: <Sparkles className="w-6 h-6" />, value: '10k+', label: 'Daily Inspirations' },
    { icon: <Users className="w-6 h-6" />, value: '50k+', label: 'Community Members' },
    { icon: <ThumbsUp className="w-6 h-6" />, value: '1M+', label: 'Positive Interactions' },
    { icon: <Award className="w-6 h-6" />, value: '100k+', label: 'Success Stories' },
  ];

  return (
    <div className="pt-24 min-h-screen bg-gradient-to-br from-gray-50 to-white">
      <SectionHeader
        title="Daily Positivity"
        subtitle="Inspiring quotes and thoughts to brighten your day"
      />

      {/* Stats Section */}
      <div className="container-custom mb-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white p-6 rounded-xl shadow-lg text-center"
            >
              <div className="text-indigo-600 mb-3 flex justify-center">{stat.icon}</div>
              <div className="text-2xl font-bold mb-1">{stat.value}</div>
              <div className="text-gray-600 text-sm">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Category Filter */}
      <div className="container-custom mb-12">
        <div className="flex justify-center space-x-4">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-6 py-2 rounded-full transition-all duration-300 ${
                selectedCategory === category
                  ? 'bg-indigo-600 text-white shadow-lg'
                  : 'bg-white text-gray-600 hover:bg-indigo-50'
              }`}
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Quotes Grid */}
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <AnimatePresence>
            {filteredQuotes.map((quote) => (
              <motion.div
                key={quote.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="bg-white rounded-xl shadow-lg overflow-hidden group"
              >
                <div className="relative h-48">
                  <img
                    src={quote.image}
                    alt=""
                    className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-black/30 group-hover:bg-black/40 transition-colors" />
                </div>
                <div className="p-6">
                  <blockquote className="text-xl font-serif mb-4">"{quote.text}"</blockquote>
                  <p className="text-gray-600 mb-6">- {quote.author}</p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex space-x-6">
                      <button
                        onClick={() => handleLike(quote.id)}
                        className={`flex items-center space-x-2 transition-colors ${
                          likedQuotes.includes(quote.id)
                            ? 'text-red-500'
                            : 'text-gray-600 hover:text-red-500'
                        }`}
                      >
                        <Heart
                          className={`w-5 h-5 ${
                            likedQuotes.includes(quote.id) ? 'fill-current' : ''
                          }`}
                        />
                        <span>{quote.likes + (likedQuotes.includes(quote.id) ? 1 : 0)}</span>
                      </button>
                      <button className="flex items-center space-x-2 text-gray-600 hover:text-indigo-600 transition-colors">
                        <MessageCircle className="w-5 h-5" />
                        <span>{quote.comments}</span>
                      </button>
                      <button className="flex items-center space-x-2 text-gray-600 hover:text-indigo-600 transition-colors">
                        <Share2 className="w-5 h-5" />
                        <span>{quote.shares}</span>
                      </button>
                    </div>
                    <span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-sm">
                      {quote.category}
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>

      {/* Daily Challenge */}
      <section className="container-custom my-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-indigo-600 text-white rounded-2xl p-8 md:p-12"
        >
          <h2 className="text-3xl font-bold mb-4">Today's Positivity Challenge</h2>
          <p className="text-xl mb-6">
            Share three things you're grateful for today and inspire others with your
            positive mindset.
          </p>
          <button className="btn bg-white text-indigo-600 hover:bg-gray-100">
            Take the Challenge
          </button>
        </motion.div>
      </section>
    </div>
  );
};

export default Positivity;